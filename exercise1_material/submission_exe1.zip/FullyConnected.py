import numpy as np
from Layers import Base
from Optimization import Optimizers


class FullyConnected(Base.BaseLayer):
    def __init__(self, input_size, output_size) : 
        super().__init__()
        self.input_size = input_size
        self.output_size = output_size
        self.weights = np.random.rand(input_size + 1, output_size) # Initialize weights randomly
        #self.bias = np.random.rand(1,output_size) # Initialize bias as zeros
        self.trainable = True
        self.gradient_weights = None
        self._optimizer = None    # protected Variable
    
     # Getter for optimizer
    @property
    def optimizer(self):
        """Returns the optimizer of this layer."""
        return self._optimizer

    # Setter for optimizer
    @optimizer.setter
    def optimizer(self, value):
        """Sets the optimizer for this layer."""
        self._optimizer = value



    def forward(self, input_tensor):
        # self.input_tensor = input_tensor
        # self.output_tensor = np.dot(input_tensor, self.weights) + self.bias
        # return self.output_tensor
     
        # Add a column of ones to the input tensor to account for the bias
        ones = np.ones((input_tensor.shape[0], 1))
        augmented_input = np.hstack((input_tensor, ones))
        self.input_tensor = augmented_input
        self.output_tensor = np.dot(augmented_input, self.weights)
        return self.output_tensor

    def backward(self, error_tensor):
    # Compute gradients
        self.gradient_weights = np.dot(self.input_tensor.T, error_tensor)
        self.gradientinput_tensor = np.dot(error_tensor, self.weights[:-1, :].T)  # Exclude bias row for input gradient

        # Update weights using the optimizer
        if self._optimizer is not None:
            self.weights = self._optimizer.calculate_update(self.weights, self.gradient_weights)

        return self.gradientinput_tensor



    
    # def backward(self, error_tensor): #gradient error
    #     self.gradient_weights = np.dot(self.input_tensor.T, error_tensor)
    #     self.gradient_bias = np.sum(error_tensor, axis=0, keepdims=True)
    #     self.gradientinput_tensor = np.dot(error_tensor, self.weights.T)

    #     if self._optimizer is not None:
    #        self.weights = self._optimizer.calculate_update(self.weights, self.gradient_weights)
    #        self.bias = self._optimizer.calculate_update(self.bias,   self.gradient_bias )


    #     return self.gradientinput_tensor
    
